// Name: Burato, Vince Art  		Section Code: T207
package game_of_war;

public interface Comparable <Card> {
	
	 public int compareTo(Card other);

}
